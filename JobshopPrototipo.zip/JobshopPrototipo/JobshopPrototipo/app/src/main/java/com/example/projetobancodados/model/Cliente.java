package com.example.projetobancodados.model;

import java.io.Serializable;

public class Cliente implements Serializable {

    private Long id;
    private String titulo;
    private String cep;
    private String categoria;
    private String descricao;

    public Cliente() {}

    public Cliente(Long id, String nome, String fone, String email, String observacao) {
        this.id = id;
        this.titulo = titulo;
        this.cep = cep;
        this.categoria = categoria;
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return this.titulo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
