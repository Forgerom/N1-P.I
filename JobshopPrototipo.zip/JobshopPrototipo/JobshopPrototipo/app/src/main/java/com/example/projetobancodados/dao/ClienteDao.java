package com.example.projetobancodados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.projetobancodados.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteDao {

    private final String TABELA = "cliente";
    private final String[] CAMPOS = {"id, titulo, cep, categoria, descricao"};
    private Conexao conexao;
    private SQLiteDatabase banco;

    public ClienteDao(Context context) {
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }

    private ContentValues preencherValores(Cliente cliente) {
        ContentValues values = new ContentValues();

        values.put("titulo", cliente.getTitulo());
        values.put("cep", cliente.getCep());
        values.put("categoria", cliente.getCategoria());
        values.put("descricao", cliente.getDescricao());

        //values.put("data", cliente.getData().getTime());

        return  values;
    }

    public long inserir (Cliente cliente) {
        ContentValues values = preencherValores(cliente);
        return banco.insert(TABELA, null, values);
    }

    public long alterar (Cliente cliente) {
        ContentValues values = preencherValores(cliente);
        String[] idValor = new String[] {String.valueOf(cliente.getId())};
        return banco.update(TABELA, values, "id = ?", idValor);
    }

    public long excluir (Cliente cliente) {
        return banco.delete(TABELA, "id = ?", new String[] {cliente.getId().toString()});
    }

    public List<Cliente> listar() {
        Cursor c = banco.query(TABELA, CAMPOS,
                null, null, null, null, null);

        List<Cliente> lista = new ArrayList<Cliente>();
        while (c.moveToNext()) {
            Cliente cliente = preencherObj(c);
            lista.add(cliente);
        }
        return lista;
    }

    public Cliente pesquisarPorId(int id) {
        Cursor c = banco.query(TABELA, CAMPOS,
                "id = ?", new String[] {String.valueOf(id)}, null, null, null);

        if (c.moveToNext()) {
            return preencherObj(c);
        }
        else {
            return null;
        }
    }

    private Cliente preencherObj(Cursor c) {
        Cliente cliente = new Cliente();
        cliente.setId(c.getLong(0));
        cliente.setTitulo(c.getString(1));
        cliente.setCep(c.getString(2));
        cliente.setCategoria(c.getString(3));
        cliente.setDescricao(c.getString(4));
        return cliente;
    }

}

