package com.example.projetobancodados;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projetobancodados.dao.ClienteDao;
import com.example.projetobancodados.model.Cliente;

public class AtvCadastro extends AppCompatActivity implements View.OnClickListener {

    Button btnGravar;
    Button btnVoltar;
    Button btnExcluir;


    EditText edtTitulo;
    EditText edtCep;
    EditText edtCategoria;
    EditText edtDescricao;

    String acao;
    Cliente c;
    ClienteDao dao;

    private void criarComponentes(){
        btnGravar = findViewById(R.id.btnGravar);
        btnGravar.setOnClickListener(this);
        btnGravar.setText(acao);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(this);
        btnExcluir = findViewById(R.id.btnExcluir);
        btnExcluir.setOnClickListener(this);
        if (acao.equals("Inserir"))
            btnExcluir.setVisibility(View.INVISIBLE);
        else
            btnExcluir.setVisibility(View.VISIBLE);

        edtTitulo     = findViewById(R.id.edtTitulo);
        edtCep     = findViewById(R.id.edtCep);
        edtCategoria    = findViewById(R.id.edtCategoria);
        edtDescricao      = findViewById(R.id.edtObs);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.atv_cadastro);

        acao = getIntent().getExtras().getString("acao");
        dao = new ClienteDao(this);
        criarComponentes();

        if (getIntent().getExtras().getSerializable("obj") != null) {
            c = (Cliente) getIntent().getExtras().getSerializable("obj");
            edtTitulo.setText(c.getTitulo());
            edtCep.setText(c.getCep());
            edtCategoria.setText(c.getCategoria());
            edtDescricao.setText(c.getDescricao());
        }
    }

    @Override
    public void onClick(View v) {
        if (v == btnVoltar) {
            finish();
        }
        else if (v == btnExcluir) {
            long id = dao.excluir(c);
            Toast.makeText(this, "Cliente " + c.getTitulo() + " foi excluído sucesso!", Toast.LENGTH_LONG).show();
            finish();
        }
        else if (v == btnGravar) {

            c.setTitulo(edtTitulo.getText().toString());
            c.setCep(edtCep.getText().toString());
            c.setCategoria(edtCategoria.getText().toString());
            c.setDescricao(edtDescricao.getText().toString());

            if (acao.equals("Inserir")) {
                long id = dao.inserir(c);
                Toast.makeText(this, "Cliente " + c.getTitulo() + " foi inserido com o id = " + id,
                        Toast.LENGTH_LONG).show();
            }
            else {
                long id = dao.alterar(c);
                Toast.makeText(this, "Cliente " + c.getTitulo() + " foi alterado com sucesso!",
                        Toast.LENGTH_LONG).show();
            }
            finish();
        }
    }
}

